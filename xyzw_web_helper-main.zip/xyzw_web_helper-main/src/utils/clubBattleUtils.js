/**
 * 获取最近的周六日期
 * 如果今天是周六，返回今天的日期；否则返回上周六的日期
 * @returns {string} 格式化的日期字符串 YYYY/MM/DD
 */
import * as XLSX from "xlsx";
/**
 * 俱乐部战斗工具函数
 */

import { isSameGameValue } from "./gameValue.js";

export function getLastSaturday() {
  const today = new Date();
  const dayOfWeek = today.getDay(); // 0=周日, 1=周一, ..., 6=周六
  today.getDate(); // 当天日期
  const year = today.getFullYear();
  const month = today.getMonth();

  let daysToSubtract = 0;
  if (dayOfWeek === 6) {
    // 今天是周六
    daysToSubtract = 0;
  } else if (dayOfWeek === 0) {
    // 今天是周日，需要判断是否是本月的第四周周日
    // 计算本月第四个周日的日期
    const firstDay = new Date(year, month, 1);
    const firstDayOfWeek = firstDay.getDay();

    // 计算本月第一个周日的日期
    const firstSunday = new Date(year, month, 1);
    if (firstDayOfWeek === 0) {
      // 本月第一天就是周日
      firstSunday.setDate(1);
    } else {
      // 否则，第一个周日是7 - firstDayOfWeek天后
      firstSunday.setDate(1 + (7 - firstDayOfWeek));
    }

    // 计算第四个周日的日期
    const fourthSunday = new Date(firstSunday);
    fourthSunday.setDate(firstSunday.getDate() + 21); // 21天 = 3周

    // 判断今天是否是第四个周日
    if (today.getDate() === fourthSunday.getDate()) {
      // 今天是第四周周日，返回今天
      daysToSubtract = 0;
    } else {
      // 不是第四周周日，返回昨天（周六）
      daysToSubtract = 1;
    }
  } else {
    // 周一到周五，计算距离上周六的天数
    daysToSubtract = dayOfWeek + 1;
  }

  const targetDate = new Date(today);
  targetDate.setDate(today.getDate() - daysToSubtract);

  const targetYear = targetDate.getFullYear();
  const targetMonth = String(targetDate.getMonth() + 1).padStart(2, "0");
  const targetDay = String(targetDate.getDate()).padStart(2, "0");

  return `${targetYear}/${targetMonth}/${targetDay}`;
}

/**
 * 判断当前时间是否是盐场时间
 */
export function isNowInLegionWarTime() {
  const today = new Date();
  const dayOfWeek = today.getDay();
  const date = today.getDate();
  const hours = today.getHours();
  const minutes = today.getMinutes();
  //用分钟好计算
  const minutesCount = hours * 60 + minutes;
  //获取本月周日的数组
  const getSundayOfMonths = (year, month) => {
    const sundayArr = [];
    for (let d = 0; d < 31; d++) {
      const temp = new Date(year, month, d);
      if (
        isSameGameValue(temp.getMonth(), month) &&
        isSameGameValue(temp.getDay(), 0)
      ) {
        sundayArr.push(d);
      }
    }
    return sundayArr;
  };

  //当前时间是20.00~21.00,周日月赛则是20.00~21.30
  //前提是周六或第四周周日 1200=20*60   1260=21*60
  if (
    isSameGameValue(dayOfWeek, 6) &&
    minutesCount >= 1195 &&
    minutesCount <= 1260
  ) {
    return true;
  }
  const sundayArr = getSundayOfMonths(today.getFullYear(), today.getMonth());
  //取第四个周末的日期
  if (
    isSameGameValue(dayOfWeek, 0) &&
    sundayArr.length >= 4 &&
    isSameGameValue(date, sundayArr[3]) &&
    minutesCount >= 1195 &&
    minutesCount <= 1290
  ) {
    return true;
  }
  return false;
}

/**
 * 判断当前是否允许使用盐场功能
 * 规则：
 * 1. 每月前四周周六
 * 2. 每月第四周周日
 * 3. 特殊修正：2026年3月1日
 */
export function isLegionWarAccessible() {
  const today = new Date();
  const year = today.getFullYear();
  const month = today.getMonth(); // 0-11
  const date = today.getDate();
  const dayOfWeek = today.getDay(); // 0-6, 0 is Sunday

  const hours = today.getHours();
  const minutes = today.getMinutes();
  const minutesCount = hours * 60 + minutes;

  // 辅助函数：检查时间是否在允许范围内
  // 周六: 19:55 - 21:00 (1195 - 1260)
  // 周日: 19:55 - 21:30 (1195 - 1290)
  const isTimeAllowed = (isSunday) => {
    const start = 1195; // 19:55
    const end = isSunday ? 1290 : 1260; // 21:30 or 21:00
    return minutesCount >= start && minutesCount <= end;
  };
  // 辅助函数：获取某个月的所有特定星期几的日期列表
  const getDaysOfMonth = (y, m, targetDayOfWeek) => {
    const days = [];
    const d = new Date(y, m, 1);
    while (d.getMonth() === m) {
      if (d.getDay() === targetDayOfWeek) {
        days.push(d.getDate());
      }
      d.setDate(d.getDate() + 1);
    }
    return days;
  };

  if (dayOfWeek === 6) {
    // 周六
    const saturdays = getDaysOfMonth(year, month, 6);
    // 判断是否是前四个周六 (index 0, 1, 2, 3)
    const index = saturdays.indexOf(date);
    if (index >= 0 && index < 4) {
      return isTimeAllowed(false);
    }
  } else if (dayOfWeek === 0) {
    // 周日
    const sundays = getDaysOfMonth(year, month, 0);
    // 判断是否是第四个周日 (index 3)
    if (sundays.length >= 4 && sundays[3] === date) {
      return isTimeAllowed(true);
    }
  }

  return false;
}

export function formatTimestamp1(timestamp) {
  const date = new Date(timestamp);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}/${month}/${day}`;
}

/**
 * 获取本月第一个周六的日期
 * @returns {string} YYYY/MM/DD
 */
export function getFirstSaturdayOfMonth() {
  const today = new Date();
  const year = today.getFullYear();
  const month = today.getMonth(); // 0-11

  // Create date for 1st day of month
  const date = new Date(year, month, 1);
  const day = date.getDay(); // 0(Sun) - 6(Sat)

  // Calculate days to add to reach first Saturday (6)
  const diff = 6 - day; // If day is 6 (Sat), diff is 0. If day is 0 (Sun), diff is 6.

  date.setDate(date.getDate() + diff);

  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");

  return `${y}/${m}/${d}`;
}

/**
 * 获取榜单查询日期 (通常是当月第四周的周日)
 * 特殊规则: 2026年2月返回 "260301"
 * @returns {string} YYMMDD
 */
export function getRankQueryDate() {
  const today = new Date();
  const year = today.getFullYear();
  const month = today.getMonth(); // 0-11

  // Special case for Feb 2026
  if (year === 2026 && month === 1) {
    return "260301";
  }

  // Calculate 4th Sunday
  // First, find the first Sunday
  const firstDay = new Date(year, month, 1);
  const dayOfWeek = firstDay.getDay();
  const firstSundayDate = 1 + ((7 - dayOfWeek) % 7);

  // 4th Sunday is 3 weeks after first Sunday
  const fourthSundayDate = firstSundayDate + 21;

  const targetDate = new Date(year, month, fourthSundayDate);

  const y = String(targetDate.getFullYear()).slice(2);
  const m = String(targetDate.getMonth() + 1).padStart(2, "0");
  const d = String(targetDate.getDate()).padStart(2, "0");

  return `${y}${m}${d}`;
}

export function getWarTypeName(warType) {
  switch (warType) {
    case 15:
      return "灰岩岛";
    case 16:
      return "进阶周赛";
    case 17:
      return "进阶月赛";
    case 18:
      return "青铜周赛";
    case 19:
      return "青铜月赛";
    case 20:
      return "秘蓝周赛";
    case 21:
      return "秘蓝月赛";
    case 22:
      return "月宫周赛";
    case 23:
      return "月宫月赛";
    case 24:
      return "天宫周赛";
    case 25:
      return "天宫月赛";
    case 6:
      return "夺旗赛";
    default:
      return "伟大航路";
  }
}

export function getRankParams(warType) {
  // Bronze: 18, 19 -> 1-1000
  if (warType === 18 || warType === 19)
    return { startRank: 1, endRank: 1000, name: "青铜岛" };
  // Blue: 20, 21 -> 1-500
  if (warType === 20 || warType === 21)
    return { startRank: 1, endRank: 500, name: "秘蓝岛" };
  // Moon: 22, 23 -> 1-200
  if (warType === 22 || warType === 23)
    return { startRank: 1, endRank: 200, name: "紫青月宫" };
  // Sun: 24, 25 -> 1-80
  if (warType === 24 || warType === 25)
    return { startRank: 1, endRank: 80, name: "黄金天宫" };

  return null;
}

// 获取战斗情况

// 获取进攻防守方情况

// 使用示例
/**
 * 格式化时间戳为可读时间
 * @param {number} timestamp - Unix时间戳（秒）
 * @returns {string} 格式化的时间字符串
 */
export function formatTimestamp(timestamp) {
  const date = new Date(timestamp * 1000);
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");
  const seconds = String(date.getSeconds()).padStart(2, "0");

  return `${month}-${day} ${hours}:${minutes}:${seconds}`;
}

/**
 * 解析战斗结果标志
 * @param {number} newWinFlag - 战斗结果标志 (1=败, 2=胜)
 * @returns {string} "胜利" 或 "失败"
 */
export function parseBattleResult(newWinFlag) {
  return newWinFlag === 2 ? "胜利" : "失败";
}

/**
 * 解析攻击类型
 * @param {number} attackType - 攻击类型 (0=进攻, 1=防守)
 * @returns {string} "进攻" 或 "防守"
 */
export function parseAttackType(attackType) {
  return attackType === 0 ? "进攻" : "防守";
}

/**
 * 格式化成员战绩数据用于导出
 * @param {Array} roleDetailsList - 成员详情列表
 * @param {string} queryDate - 查询日期
 * @returns {string} 格式化的文本
 */
export function formatBattleRecordsForExport(roleDetailsList, queryDate) {
  if (!roleDetailsList || roleDetailsList.length === 0) {
    return "暂无战绩数据";
  }

  const lines = [
    `俱乐部盐场战绩 - ${queryDate}`,
    `参战人数: ${roleDetailsList.length}`,
    "─".repeat(40),
    "",
  ];
  // 按击杀数排序
  const sortedMembers = [...roleDetailsList].sort(
    (a, b) => (b.winCnt || 0) - (a.winCnt || 0),
  );

  // 计算总计
  let totalKills = 0;
  let totalDeaths = 0;
  let totalSieges = 0;
  let totalResurrection = 0;

  sortedMembers.forEach((member, index) => {
    const { name, winCnt, loseCnt, buildingCnt } = member;
    const Resurrection = Math.max(loseCnt - 6, 0);
    totalKills += winCnt || 0;
    totalDeaths += loseCnt || 0;
    totalSieges += buildingCnt || 0;
    totalResurrection += Resurrection || 0;

    lines.push(
      `${index + 1}. ${name}  击杀${winCnt || 0}  死亡${loseCnt || 0}  攻城${buildingCnt || 0}  复活丹${Resurrection || 0}`,
    );
  });

  lines.push("");
  lines.push("─".repeat(40));
  lines.push(
    `总计  击杀${totalKills}  死亡${totalDeaths}  攻城${totalSieges}  复活丹${totalResurrection}`,
  );
  lines.push("");
  lines.push(`导出时间: ${new Date().toLocaleString("zh-CN")}`);

  // 构造盐场数据工作表
  const worksheetData = [
    ["排名", "ID", "成员名称", "击杀数", "死亡数", "攻城数", "K/D", "复活丹"],
    ...roleDetailsList
      .sort((a, b) => (b.winCnt || 0) - (a.winCnt || 0))
      .map((member, index) => [
        index + 1,
        member.roleId || 0,
        member.name || "",
        member.winCnt || 0,
        member.loseCnt || 0,
        member.buildingCnt || 0,
        (member.winCnt / member.loseCnt).toFixed(2),
        Math.max(member.loseCnt - 6, 0),
      ]),
  ];

  // 构造战斗数据工作表
  const processedData = roleDetailsList
    .map((member) => {
      const targetRoleList = member.targetRoleList || [];
      return targetRoleList
        .filter((battle) => battle !== null)
        .map((battle) => {
          const targetRoleInfo = battle.targetRoleInfo || {};
          return [
            battle.roleInfo.roleId || 0,
            battle.roleInfo.name || "",
            targetRoleInfo.roleId || 0,
            targetRoleInfo.name || "",
            battle.attackType || 0,
            battle.newWinFlag || 0,
            battle.timestamp || 0,
          ];
        });
    })
    .flat(); // 将成员的战斗记录数组“扁平化”为单个大数组
  const keys = [
    "roleId",
    "roleName",
    "targetRoleId",
    "targetRoleName",
    "attackType",
    "newWinFlag",
    "timestamp",
  ];
  const processedDataWithKeys = processedData.map((subArray) => {
    const obj = {};
    for (let i = 0; i < subArray.length; i++) {
      obj[keys[i]] = subArray[i]; // 用键名映射字段值
    }
    return obj;
  });

  console.log(processedDataWithKeys);
  const worksheetData1 = [
    [
      "玩家ID",
      "玩家名称",
      "对手ID",
      "对手名称",
      "对战方",
      "战斗结果",
      "战斗时间",
    ],
    ...processedDataWithKeys.map((battle) => [
      battle.roleId || 0,
      battle.roleName || "",
      battle.targetRoleId || 0,
      battle.targetRoleName || "",
      parseAttackType(battle.attackType || 0),
      parseBattleResult(battle.newWinFlag || 0),
      formatTimestamp(battle.timestamp || 0),
    ]),
  ];
  // 创建工作簿
  const workbook = XLSX.utils.book_new();
  const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);
  const worksheet1 = XLSX.utils.aoa_to_sheet(worksheetData1);
  // 添加总计行
  XLSX.utils.sheet_add_aoa(
    worksheet,
    [
      [
        "总计",
        "",
        "",
        roleDetailsList.reduce((sum, m) => sum + (m.winCnt || 0), 0),
        roleDetailsList.reduce((sum, m) => sum + (m.loseCnt || 0), 0),
        roleDetailsList.reduce((sum, m) => sum + (m.buildingCnt || 0), 0),
        roleDetailsList.reduce(
          (sum, m) => sum + (Math.max(m.loseCnt - 6, 0) || 0),
          0,
        ),
      ],
    ],
    { origin: -1 },
  );

  // 设置列宽
  worksheet["!cols"] = [
    { wch: 8 },
    { wch: 15 },
    { wch: 15 },
    { wch: 8 },
    { wch: 8 },
    { wch: 8 },
  ];
  worksheet1["!cols"] = [
    { wch: 15 },
    { wch: 15 },
    { wch: 15 },
    { wch: 15 },
    { wch: 15 },
    { wch: 15 },
    { wch: 15 },
  ];

  // 添加到工作簿
  XLSX.utils.book_append_sheet(workbook, worksheet, "战绩数据");
  XLSX.utils.book_append_sheet(workbook, worksheet1, "战斗数据");

  // 生成文件名
  const fileName = `俱乐部战绩_${queryDate.replace(/\//g, "-")}.xlsx`;

  // 触发下载
  XLSX.writeFile(workbook, fileName);
  return lines.join("\n");
}
/**
 * 复制文本到剪贴板
 * @param {string} text - 要复制的文本
 * @returns {Promise<void>}
 */
export async function copyToClipboard(text) {
  if (navigator.clipboard && window.isSecureContext) {
    // 现代浏览器
    await navigator.clipboard.writeText(text);
  } else {
    // 降级方案
    const textArea = document.createElement("textarea");
    textArea.value = text;
    textArea.style.position = "fixed";
    textArea.style.left = "-999999px";
    textArea.style.top = "-999999px";
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();

    try {
      document.execCommand("copy");
    } catch (err) {
      throw new Error("复制失败");
    } finally {
      textArea.remove();
    }
  }
}
